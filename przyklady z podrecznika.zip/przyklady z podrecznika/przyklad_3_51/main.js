// Przyklad 3.51
var tekst = "Obiekty języka JavaScript";
var x = tekst.substring(15, 19);