//przyklad 3.57
var tab3 = new Array('Anna', 'Adam', 'Piotr', 'Ewa');var tab4 = ['Paweł', 'Marcin', 'Ela'];