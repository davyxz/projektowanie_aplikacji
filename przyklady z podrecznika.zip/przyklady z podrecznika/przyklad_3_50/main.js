// przyklad 3.50
var tekst = "Obiekty języka JavaScript";
var dlug = tekst.length;