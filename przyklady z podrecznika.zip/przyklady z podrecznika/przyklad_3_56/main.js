//Przykład 3.56
var tab1 = new Array(10);
var tab2 = [15];