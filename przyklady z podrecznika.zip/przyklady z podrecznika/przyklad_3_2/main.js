document.write("Napisz program w języku JavaScript");
//Przykład 3.2