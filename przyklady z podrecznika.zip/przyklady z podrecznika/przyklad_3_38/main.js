/ przyklad 3.38
parseFloat("432.37");