// przyklad 3.12
var a = "Warszawa";
var b = 'Kraków';