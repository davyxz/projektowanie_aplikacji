var napisz = "Witaj w szkole";
document.write(napisz.toUpperCase() + "<br>");
document.write("Długość tekstu: " + napisz.length);