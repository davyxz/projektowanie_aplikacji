//Przykład 3.29
function suma(a, b) {
    var c = a + b;
    return c;
}