//Przykład 3.9
var x, y, Nazwa;
var miasto = "Warszawa";
var Miasto = 5;
let tekst = "Dowolny tekst";