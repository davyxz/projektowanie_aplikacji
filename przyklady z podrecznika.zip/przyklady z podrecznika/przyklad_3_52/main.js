// Przykład 3.52
var tekst = "Obiekty języka JavaScript";
var x = tekst.toLowerCase();